# ASP.NET Core Authorization Samples

**Now updated for RTM, async all the handlers!**

This is a sarcastic, opinionated set of samples I used to validate the user requirements we had for asp.net's new policy based authorization. 

I use them as part of a presentation on new features. They include things **NOT to do**, so don't cut and paste from this just because it's samples from some random Microsoft employee.

Instead [go read the documentation](https://docs.asp.net/en/latest/security/authorization/index.html).

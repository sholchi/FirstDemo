﻿namespace AspNetAuthorization.Authorization
{
    public interface IAuthorizationHandler<T>
    {
    }
}
﻿/// <autosync enabled="true" />
/// <reference path="lib/bootstrap/js/bootstrap.js" />
/// <reference path="lib/jquery/jquery.js" />
/// <reference path="lib/jquery-validation/jquery.validate.js" />
/// <reference path="lib/jquery-validation-unobtrusive/jquery.validate.unobtrusive.js" />


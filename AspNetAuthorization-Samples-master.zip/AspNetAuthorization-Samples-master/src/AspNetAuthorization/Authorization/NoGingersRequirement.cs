﻿using Microsoft.AspNetCore.Authorization;

namespace AspNetAuthorization.Authorization
{
    public class NoGingersRequirement : IAuthorizationRequirement
    {
    }
}

﻿using Microsoft.AspNetCore.Authorization;


namespace AspNetAuthorization.Authorization
{
    public class EnterBuildingRequirement : IAuthorizationRequirement
    {
    }
}

﻿using System;

namespace AspNetAuthorization.Models
{
    public class Document
    {
        public string Author { get; set; }
    }
}